import MPagesFusionCustomComponent from "./MPagesFusionCustomComponent";

export { MPagesFusionCustomComponent as default };
