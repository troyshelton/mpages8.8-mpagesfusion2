import getData from "./getData";

export default getData;

