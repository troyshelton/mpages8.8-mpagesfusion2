window.i18n.discernabu.MPagesFusionCustomComponent = {
    /* The i18n specific to component */
};
